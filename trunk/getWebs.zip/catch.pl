#!E:goss\project\perl\getWebs
#ץȡԶ����վ������

use Encode;
use LWP::Simple;
use utf8; 
#�������ݿ������ļ�
require 'conn.pl';

my $beginid = 199;
my $endid   = 2696863;

#my $html = 'goss 800 goss@bwebs.com';

open LOG,'>txt/data.sql';
for($i=$beginid;$i<=$endid;$i++){
	my $url = "http://www.qjy168.com/shop/userinfo.php?userid=$i";
	my $html = get( "$url" ) || next;
	utf8::encode($html);

	#utf8::decode($html);
	#syswrite(LOG,"$url\r\n");
	#��˾����

	@company = $html =~m/\<strong\>.*<\/strong\>/g;
	#����
	@name = $html =~m/\<b\>.*\<\/b\>/g;

	#�绰����
	@telephone = $html =~m/\d+-\d+-\d+/ig;

	#�ֻ�����
	@mobie = $html =~m#15\d{9}|13\d{9}|18\d{9}#sg;

	@msn = $html =~m/[0-9a-zA-Z_]+\@[0-9a-zA-Z_]+\.[0-9a-zA-Z_]+/g;
	
	@name[0] =~ s/\<b\>|\<\/b\>//ig;
	@company[0] =~ s/\<strong\>|\<\/strong\>//ig;
	
	$uname = @name[0];
	$ucompany = @company[0];
	$utelephone = @telephone[0];
	$umobie = @mobie[0];
	$umsn = @msn[0];
	
	print "$utelephone\r\n";
	#syswrite(LOG,"$ucompany\t$uname\t$utelephone\t$umobie\t$umsn\r\n");
	$sql = "insert into users(qid,name,company,telephone,mobie,msn)values($i,'$uname','$ucompany','$utelephone','$umobie','$umsn');";
		
	if($ucompany){
		syswrite(LOG,$sql);
		#$dbh->do($sql);
	}
	#syswrite(LOG,$sql);
	#print "@company";

	#print "@name";
	
	#print "@telephone";

	#print "@mobie";

	#print "@msn";
}
